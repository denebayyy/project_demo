import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../user.model';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  latestUser: User = {email: "", password: ""};
  submitted = false;

  constructor(private userService: UserService){};

  onSubmit(form: NgForm){
    if(form.valid){
      console.log(form.value.email + " and " + form.value.password);
      this.latestUser = {email: form.value.email, password: form.value.password};
      this.userService.addNewUser(this.latestUser);
      this.submitted = true;
    }
  }
}
