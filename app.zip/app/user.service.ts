import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { User } from "./user.model";

@Injectable({providedIn:"root"})
export class UserService{
  users: User[] = [];
  usersUpdated = new Subject<User[]>();

  constructor(){}

  addNewUser(user: User){
    this.users.push(user);
    this.usersUpdated.next([...this.users]);
  }

  getUsers(){
    return [...this.users];
  }
}
