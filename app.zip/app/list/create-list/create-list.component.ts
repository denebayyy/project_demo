import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ListService } from '../list.service';

@Component({
  selector: 'app-create-list',
  templateUrl: './create-list.component.html',
  styleUrls: ['./create-list.component.css']
})
export class CreateListComponent {
  constructor(private listService: ListService){}

  onAddList(form: NgForm){
  if(form.valid){
      const list = {title: form.value.title, body: form.value.body};
      this.listService.addList(list)
    }
  }
}
