export interface List{
  title: string;
  body: string;
}
