import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { List } from "./list.model";

@Injectable({providedIn:"root"})
export class ListService{
  lists: List[] = [];
  listsUpdated = new Subject<List[]>();

  addList(list: List){
    this.lists.push(list);
    this.listsUpdated.next([...this.lists]);
  }

  deleteList(list: List){
    console.log("List " + list.title + " deleted");
    this.lists.filter(list =>{
      return list !== list
    });
    this.listsUpdated.next([...this.lists]);
  }

  getLists(){
    return [...this.lists];
  }
}
