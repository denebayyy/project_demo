import { Component, OnInit } from '@angular/core';
import { List } from '../list.model';
import { ListService } from '../list.service';

@Component({
  selector: 'app-all-lists',
  templateUrl: './all-lists.component.html',
  styleUrls: ['./all-lists.component.css']
})
export class AllListsComponent implements OnInit{
  currentLists: List[] = [];

  constructor(private listService: ListService){}

  ngOnInit(): void {
    this.currentLists=this.listService.getLists();
    this.listService.listsUpdated.subscribe(
      (data) =>{
        this.currentLists = [...this.listService.getLists()];
        console.log("sent")
      }
    )
  }


}
